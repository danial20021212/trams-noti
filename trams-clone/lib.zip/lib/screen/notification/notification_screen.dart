import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/services.dart';
import 'package:flutter_neumorphic/flutter_neumorphic.dart';
import 'package:get/get.dart';

import '../../components/Neumorphic/navbar.dart';

import 'package:tram/controller/auth/auth_controller.dart';
import 'package:tram/noti_services/push_service.dart';

/// Notifications page.
/// For now it has test buttons to ask permission and show this phone's FCM token.
/// The real list of notifications will go in the body later.
class NotificationScreen extends StatefulWidget {
  const NotificationScreen({super.key});

  @override
  State<NotificationScreen> createState() => _NotificationScreenState();
}

class _NotificationScreenState extends State<NotificationScreen> {
  String _status = 'Permission: not asked yet';
  String? _token;

  final _toController = TextEditingController();
  String _sendResult = '';
  bool _sending = false;

  Future<void> _sendToUser() async {
    final to = _toController.text.trim();
    final from = Get.find<AuthController>().accessName();
    if (to.isEmpty || from == null) return;

    setState(() {
      _sending = true;
      _sendResult = '';
    });
    final result = await PushService.sendNotification(
      fromUsername: from,
      toUsername: to,
      title: 'New message',
      body: '$from sent you a notification',
    );
    if (!mounted) return;
    setState(() {
      _sending = false;
      _sendResult = result;
    });
  }

  @override
  void dispose() {
    _toController.dispose();
    super.dispose();
  }


  Future<void> _requestPermission() async {
    final settings = await FirebaseMessaging.instance.requestPermission();
    setState(() {
      _status = 'Permission: ${settings.authorizationStatus.name}';
    });
  }

  Future<void> _getToken() async {
    final token = await FirebaseMessaging.instance.getToken();
    setState(() => _token = token);
  }

  Future<void> _copyToken() async {
    if (_token == null) return;
    await Clipboard.setData(ClipboardData(text: _token!));
    Get.snackbar(
      'Copied',
      'FCM token copied to clipboard',
      colorText: Colors.black,
      margin: const EdgeInsets.all(10),
      duration: const Duration(seconds: 2),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const NeumorphicNavBar(
        title: 'Notifications',
        showDrawer: false, // shows a back arrow instead of the menu icon
        color: Color(0xfff3f8fe),
      ),
      backgroundColor: const Color(0xfff3f8fe),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const Text('No notifications yet'),
            const SizedBox(height: 30),
            if (kIsWeb)
              const Text('FCM test buttons only work on the Android app.')
            else ...[
              // NEW: send a notification to another user
              TextField(
                controller: _toController,
                decoration: const InputDecoration(
                  labelText: 'Send to username',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              NeumorphicButton(
                onPressed: _sending ? null : _sendToUser,
                child: Text(_sending ? 'Sending...' : 'Send notification'),
              ),
              const SizedBox(height: 8),
              Text(_sendResult),
              const SizedBox(height: 30),

              // Existing test buttons
              Text(_status),
              const SizedBox(height: 12),
              NeumorphicButton(
                onPressed: _requestPermission,
                child: const Text('1. Allow notifications'),
              ),
              const SizedBox(height: 20),
              NeumorphicButton(
                onPressed: _getToken,
                child: const Text('2. Get FCM token'),
              ),
              const SizedBox(height: 12),
              if (_token != null) ...[
                SelectableText(
                  _token!,
                  style: const TextStyle(fontSize: 12),
                ),
                const SizedBox(height: 12),
                NeumorphicButton(
                  onPressed: _copyToken,
                  child: const Text('Copy token'),
                ),
              ],
            ],
          ],
        ),
      ),
    );
  }
}